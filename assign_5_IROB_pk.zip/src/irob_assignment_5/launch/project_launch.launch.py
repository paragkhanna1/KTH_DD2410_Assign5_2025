
#Add necessary imports

#USE:
use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    
#pkg_irob_assignment_5 = "/home/parag/ros_as1_test/src/irob_assignment_5"
#pkg_irob_assignment_5 = get_package_share_directory('irob_assignment_5') #better way to do above!

# Launch node/executable goal_server , add parameter goal_params_SM.yaml or goal_params_BT.yaml as needed 
# Launch node/executable activation_server
# Launch node/executable at_goal_server 


